import { AdminDashboard2Component } from "./../admin/admin-dashboard2/admin-dashboard2.component";
import { AdminDashboard1Component } from "./../admin/admin-dashboard1/admin-dashboard1.component";
import { StarterComponent } from "./../starter/starter.component";
import { AdminComponent } from "./../admin/admin.component";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { AdminRoutingModule } from "../admin/admin-routing/admin-routing.module";
import { LoginComponent } from "../login/login.component";
import { RegisterComponent } from "../register/register.component";
@NgModule({
  imports: [
    RouterModule.forRoot([
      { path: "", redirectTo: "login", pathMatch: "full" },
      { path: "starter", component: StarterComponent },
      { path: "login", component: LoginComponent },
      { path: "register", component: RegisterComponent }
    ])
  ],
  declarations: [],
  exports: [RouterModule, AdminRoutingModule]
})
export class AppRoutingModule {}
