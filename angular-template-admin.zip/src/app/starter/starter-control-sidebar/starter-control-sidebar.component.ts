import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-starter-control-sidebar',
  templateUrl: './starter-control-sidebar.component.html',
  styleUrls: ['./starter-control-sidebar.component.css']
})
export class StarterControlSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
